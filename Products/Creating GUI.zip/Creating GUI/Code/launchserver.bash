#!/bin/bash

python3 -m http.server 7000 --bind 100.121.193.21 --directory ~/web
