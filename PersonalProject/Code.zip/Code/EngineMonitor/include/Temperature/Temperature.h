#include <Temperature/ITemperature.h>
class Temperature : public ITemperature
{
    public:
    Temperature();
    int getTemperature();
}; 