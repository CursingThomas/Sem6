class ITemperature
{
    public:
    virtual int getTemperature() = 0;
    
    protected:
};