class IRpm
{
    public:
    virtual int getRpm() = 0;
    
    protected:                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
};