#include <Temperature/Temperature.h>

Temperature::Temperature() // add pins
{

};


int Temperature::getTemperature() 
{
    return 23;
};