#include <Temperature/ITemperature.h>

